package com.aiclassnotes.app.data.repository

import com.aiclassnotes.app.data.db.NoteDao
import com.aiclassnotes.app.data.model.*
import kotlinx.coroutines.flow.Flow

class NoteRepository(private val noteDao: NoteDao) {

    val allSubjects: Flow<List<SubjectEntity>> = noteDao.getAllSubjects()

    fun getSegmentsForSubject(subjectId: Long): Flow<List<SegmentEntity>> {
        return noteDao.getSegmentsForSubject(subjectId)
    }

    fun getSessionsForSegment(segmentId: Long): Flow<List<NoteSessionEntity>> {
        return noteDao.getSessionsForSegment(segmentId)
    }

    suspend fun renameSegment(segmentId: Long, newName: String) {
        val segment = noteDao.getSegmentById(segmentId)
        if (segment != null) {
            noteDao.updateSegment(segment.copy(name = newName.trim()))
        }
    }

    suspend fun createNoteSession(subjectId: Long, segmentId: Long, formattedDate: String): Long {
        val session = NoteSessionEntity(
            subjectId = subjectId,
            segmentId = segmentId,
            timestamp = System.currentTimeMillis(),
            formattedDate = formattedDate,
            title = "Class Notes",
            status = "ACTIVE"
        )
        val sessionId = noteDao.insertSession(session)
        // Automatically create Page 1
        noteDao.insertPage(NotePageEntity(sessionId = sessionId, pageIndex = 1))
        return sessionId
    }

    suspend fun completeNoteSession(sessionId: Long) {
        val session = NoteSessionEntity(
            id = sessionId,
            subjectId = 0,
            segmentId = 0,
            timestamp = 0,
            formattedDate = "",
            title = "Class Notes",
            status = "COMPLETED"
        )
        // Update session status
    }

    suspend fun addNoteElement(pageId: Long, element: NoteElementEntity): Long {
        return noteDao.insertElement(element.copy(pageId = pageId))
    }

    suspend fun getPagesWithElements(sessionId: Long): List<Pair<NotePageEntity, List<NoteElementEntity>>> {
        val pages = noteDao.getPagesForSession(sessionId)
        return pages.map { page ->
            Pair(page, noteDao.getElementsForPage(page.id))
        }
    }
}
