package com.aiclassnotes.app.ui.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.aiclassnotes.app.R
import com.aiclassnotes.app.data.model.SubjectEntity

class SubjectAdapter(
    private val subjects: List<SubjectEntity>,
    private val onSubjectClicked: (SubjectEntity) -> Unit
) : RecyclerView.Adapter<SubjectAdapter.SubjectViewHolder>() {

    class SubjectViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvNumber: TextView = view.findViewById(R.id.tvSubjectNumber)
        val tvName: TextView = view.findViewById(R.id.tvSubjectName)
        val tvSemester: TextView = view.findViewById(R.id.tvSubjectSemester)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SubjectViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_subject, parent, false)
        return SubjectViewHolder(view)
    }

    override fun onBindViewHolder(holder: SubjectViewHolder, position: Int) {
        val subject = subjects[position]
        holder.tvNumber.text = "${position + 1}"
        holder.tvName.text = subject.name
        holder.tvSemester.text = "${subject.semester} • 6 Segments"
        holder.itemView.setOnClickListener { onSubjectClicked(subject) }
    }

    override fun getItemCount(): Int = subjects.size
}
