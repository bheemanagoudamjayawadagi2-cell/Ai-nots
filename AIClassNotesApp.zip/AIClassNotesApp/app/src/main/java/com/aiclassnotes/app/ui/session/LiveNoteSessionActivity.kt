package com.aiclassnotes.app.ui.session

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.aiclassnotes.app.AIClassNotesApplication
import com.aiclassnotes.app.R
import com.aiclassnotes.app.ai.ClassUnderstandingEngine
import com.aiclassnotes.app.data.model.NoteElementType
import com.aiclassnotes.app.databinding.ActivityLiveSessionBinding
import com.aiclassnotes.app.service.FloatingOverlayService
import com.aiclassnotes.app.service.MediaCaptureService
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class LiveNoteSessionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLiveSessionBinding

    private var subjectName: String = ""
    private var segmentName: String = ""
    private var subjectId: Long = 1
    private var segmentId: Long = 1
    private var sessionId: Long = -1

    private var isPaused = false
    private var elapsedSeconds = 0
    private val timerHandler = Handler(Looper.getMainLooper())
    private val timerRunnable = object : Runnable {
        override fun run() {
            if (!isPaused) {
                elapsedSeconds++
                val hours = elapsedSeconds / 3600
                val minutes = (elapsedSeconds % 3600) / 60
                val secs = elapsedSeconds % 60
                binding.tvTimer.text = String.format("%02d:%02d:%02d", hours, minutes, secs)
            }
            timerHandler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLiveSessionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        subjectName = intent.getStringExtra("subject_name") ?: "Managerial Economics"
        segmentName = intent.getStringExtra("segment_name") ?: "Segment 2"
        subjectId = intent.getLongExtra("subject_id", 1L)
        segmentId = intent.getLongExtra("segment_id", 1L)
        sessionId = intent.getLongExtra("session_id", -1L)

        binding.tvSessionSubject.text = subjectName
        binding.tvSessionSegment.text = "$segmentName • Taking Notes"

        timerHandler.postDelayed(timerRunnable, 1000)

        // Listen for progressive live-written handwritten notes
        lifecycleScope.launch {
            ClassUnderstandingEngine.instance.liveNoteElements.collectLatest { element ->
                binding.a4PaperView.addElementProgressively(element)
            }
        }

        setupButtons()
    }

    private fun setupButtons() {
        binding.btnPauseResume.setOnClickListener {
            if (!isPaused) {
                isPaused = true
                binding.btnPauseResume.text = "RESUME"
                binding.btnPauseResume.setBackgroundColor(0xFF2563EB.toInt())
                binding.tvSessionSegment.text = "$segmentName • Paused"
                binding.statusIndicator.setBackgroundResource(R.drawable.bg_status_paused)

                val intent = Intent(this, MediaCaptureService::class.java).apply {
                    action = MediaCaptureService.ACTION_PAUSE
                }
                startService(intent)
            } else {
                isPaused = false
                binding.btnPauseResume.text = "PAUSE"
                binding.btnPauseResume.setBackgroundColor(0xFFD97706.toInt())
                binding.tvSessionSegment.text = "$segmentName • Taking Notes"
                binding.statusIndicator.setBackgroundResource(R.drawable.bg_status_active)

                val intent = Intent(this, MediaCaptureService::class.java).apply {
                    action = MediaCaptureService.ACTION_RESUME
                }
                startService(intent)
            }
        }

        binding.btnStopSave.setOnClickListener {
            stopAndSave()
        }

        binding.btnMinimize.setOnClickListener {
            minimizeToFloatingAssistant()
        }
    }

    private fun stopAndSave() {
        timerHandler.removeCallbacks(timerRunnable)

        val intent = Intent(this, MediaCaptureService::class.java).apply {
            action = MediaCaptureService.ACTION_STOP
        }
        startService(intent)

        Toast.makeText(this, "Session Saved to $subjectName → $segmentName", Toast.LENGTH_LONG).show()
        finish()
    }

    private fun minimizeToFloatingAssistant() {
        if (Settings.canDrawOverlays(this)) {
            val intent = Intent(this, FloatingOverlayService::class.java).apply {
                putExtra("subject", subjectName)
                putExtra("segment", segmentName)
                putExtra("is_session_active", !isPaused)
            }
            startService(intent)
            // Move activity to back (minimized)
            moveTaskToBack(true)
        } else {
            Toast.makeText(this, "Overlay permission required for floating button", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        timerHandler.removeCallbacks(timerRunnable)
    }
}
