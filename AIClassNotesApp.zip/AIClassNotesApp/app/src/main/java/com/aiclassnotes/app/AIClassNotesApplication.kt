package com.aiclassnotes.app

import android.app.Application
import com.aiclassnotes.app.data.db.AppDatabase
import com.aiclassnotes.app.data.repository.NoteRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class AIClassNotesApplication : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val database by lazy { AppDatabase.getDatabase(this, applicationScope) }
    val repository by lazy { NoteRepository(database.noteDao()) }

    override fun onCreate() {
        super.onCreate()
        // Database will initialize the 5 subjects and 6 segments with NO fake notes
    }
}
