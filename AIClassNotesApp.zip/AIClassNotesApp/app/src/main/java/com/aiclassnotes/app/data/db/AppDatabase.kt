package com.aiclassnotes.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.aiclassnotes.app.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        SubjectEntity::class,
        SegmentEntity::class,
        NoteSessionEntity::class,
        NotePageEntity::class,
        NoteElementEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun noteDao(): NoteDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ai_class_notes.db"
                )
                .addCallback(AppDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database.noteDao())
                }
            }
        }

        suspend fun populateInitialData(dao: NoteDao) {
            // Initial 5 MBA Subjects required by user
            val defaultSubjects = listOf(
                SubjectEntity(id = 1, name = "Managerial Economics", semester = "Semester 1", displayOrder = 1),
                SubjectEntity(id = 2, name = "Business Communication", semester = "Semester 1", displayOrder = 2),
                SubjectEntity(id = 3, name = "Statistics for Managers", semester = "Semester 1", displayOrder = 3),
                SubjectEntity(id = 4, name = "Accounting for Managers", semester = "Semester 1", displayOrder = 4),
                SubjectEntity(id = 5, name = "Principles of Management", semester = "Semester 1", displayOrder = 5)
            )
            dao.insertSubjects(defaultSubjects)

            // Each subject strictly starts with Segment 1 through Segment 6
            val segments = mutableListOf<SegmentEntity>()
            for (subId in 1..5) {
                for (segNum in 1..6) {
                    segments.add(
                        SegmentEntity(
                            subjectId = subId.toLong(),
                            segmentNumber = segNum,
                            name = "Segment $segNum"
                        )
                    )
                }
            }
            dao.insertSegments(segments)

            // CRITICAL: NO FAKE DATA!
            // note_sessions, note_pages, and note_elements are left 100% EMPTY.
            // Notes will only appear when the user explicitly starts a live note session!
        }
    }
}
