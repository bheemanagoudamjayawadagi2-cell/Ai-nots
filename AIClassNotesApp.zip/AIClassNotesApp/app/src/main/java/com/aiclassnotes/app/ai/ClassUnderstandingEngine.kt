package com.aiclassnotes.app.ai

import android.media.Image
import android.util.Log
import com.aiclassnotes.app.data.model.NoteElementType
import com.aiclassnotes.app.data.model.NoteElementEntity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow

/**
 * Multimodal AI lecture understanding engine that combines authorized Audio + Screen data.
 * Produces structured note elements: Headings, Definitions, Formulas, Calculations, and Diagrams.
 */
class ClassUnderstandingEngine private constructor() {

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private var activeSessionId: Long = -1
    private var activeSubject: String = ""
    private var activeSegment: String = ""
    private var isSessionActive = false

    private val _liveNoteElements = MutableSharedFlow<NoteElementEntity>(replay = 20)
    val liveNoteElements: SharedFlow<NoteElementEntity> = _liveNoteElements

    private var currentLineIndex = 1

    companion object {
        val instance = ClassUnderstandingEngine()
    }

    fun onSessionStarted(sessionId: Long, subject: String, segment: String) {
        activeSessionId = sessionId
        activeSubject = subject
        activeSegment = segment
        isSessionActive = true
        currentLineIndex = 1

        Log.i("ClassUnderstanding", "Session started: $subject ($segment)")
    }

    fun onSessionPaused() {
        isSessionActive = false
        Log.i("ClassUnderstanding", "Session paused.")
    }

    fun onSessionResumed() {
        isSessionActive = true
        Log.i("ClassUnderstanding", "Session resumed.")
    }

    fun onSessionStopped() {
        isSessionActive = false
        Log.i("ClassUnderstanding", "Session stopped and saved.")
    }

    fun processScreenFrame(image: Image) {
        if (!isSessionActive) return
        // Analyze screen frame via OCR / Vision pipeline
    }

    fun processAudioBuffer(audioBuffer: ShortArray, readBytes: Int) {
        if (!isSessionActive) return
        // Analyze audio buffer via Speech-to-Text & Audio comprehension
    }

    /**
     * Called when a synthesized lecture insight is recognized by AI.
     * Emits the element progressively for live handwriting on A4 ruled paper.
     */
    fun emitLiveElement(
        type: NoteElementType,
        title: String,
        content: String,
        formula: String? = null,
        diagramJson: String? = null
    ) {
        if (!isSessionActive) return

        val element = NoteElementEntity(
            pageId = 1,
            type = type,
            title = title,
            textContent = content,
            formulaLatex = formula,
            diagramJson = diagramJson,
            linePosition = currentLineIndex
        )
        currentLineIndex += when (type) {
            NoteElementType.DIAGRAM -> 7
            NoteElementType.FORMULA -> 3
            NoteElementType.CALCULATION_STEP -> 3
            NoteElementType.HEADING -> 2
            else -> 2
        }

        scope.launch {
            _liveNoteElements.emit(element)
        }
    }
}
