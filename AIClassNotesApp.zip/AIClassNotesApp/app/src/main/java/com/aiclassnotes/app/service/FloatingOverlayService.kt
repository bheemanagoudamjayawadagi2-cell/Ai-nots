package com.aiclassnotes.app.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.Button
import android.widget.TextView
import com.aiclassnotes.app.R
import com.aiclassnotes.app.ui.MainActivity
import com.aiclassnotes.app.ui.session.LiveNoteSessionActivity

class FloatingOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var pillView: View? = null
    private var controlCardView: View? = null

    private var pillParams: WindowManager.LayoutParams? = null
    private var isExpanded = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createFloatingPill()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val subject = intent?.getStringExtra("subject") ?: "Managerial Economics"
        val segment = intent?.getStringExtra("segment") ?: "Segment 2"
        val isSessionActive = intent?.getBooleanExtra("is_session_active", false) ?: false

        updateOverlayData(subject, segment, isSessionActive)
        return START_NOT_STICKY
    }

    private fun createFloatingPill() {
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        pillParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50
            y = 200
        }

        val inflater = LayoutInflater.from(this)
        pillView = inflater.inflate(R.layout.overlay_floating_pill, null)

        // Setup Dragging and Tap
        setupTouchListener(pillView!!, pillParams!!)

        pillView?.setOnClickListener {
            toggleControlPanel()
        }

        windowManager?.addView(pillView, pillParams)
    }

    private fun setupTouchListener(view: View, params: WindowManager.LayoutParams) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isClick = false

        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isClick = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = (event.rawX - initialTouchX).toInt()
                    val deltaY = (event.rawY - initialTouchY).toInt()
                    if (Math.abs(deltaX) > 10 || Math.abs(deltaY) > 10) {
                        isClick = false
                    }
                    params.x = initialX + deltaX
                    params.y = initialY + deltaY
                    windowManager?.updateViewLayout(view, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isClick) {
                        v.performClick()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun toggleControlPanel() {
        if (!isExpanded) {
            showControlPanel()
        } else {
            hideControlPanel()
        }
    }

    private fun showControlPanel() {
        if (controlCardView != null) return

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val cardParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        val inflater = LayoutInflater.from(this)
        controlCardView = inflater.inflate(R.layout.overlay_control_panel, null)

        controlCardView?.findViewById<Button>(R.id.btnOverlayPause)?.setOnClickListener {
            val intent = Intent(this, MediaCaptureService::class.java).apply {
                action = MediaCaptureService.ACTION_PAUSE
            }
            startService(intent)
            controlCardView?.findViewById<TextView>(R.id.tvOverlayStatus)?.text = "⏸ Paused"
            controlCardView?.findViewById<TextView>(R.id.tvOverlayStatus)?.setTextColor(0xFFF59E0B.toInt())
        }

        controlCardView?.findViewById<Button>(R.id.btnOverlayResume)?.setOnClickListener {
            val intent = Intent(this, MediaCaptureService::class.java).apply {
                action = MediaCaptureService.ACTION_RESUME
            }
            startService(intent)
            controlCardView?.findViewById<TextView>(R.id.tvOverlayStatus)?.text = "● Taking Notes"
            controlCardView?.findViewById<TextView>(R.id.tvOverlayStatus)?.setTextColor(0xFF34D399.toInt())
        }

        controlCardView?.findViewById<Button>(R.id.btnOverlayStopSave)?.setOnClickListener {
            val intent = Intent(this, MediaCaptureService::class.java).apply {
                action = MediaCaptureService.ACTION_STOP
            }
            startService(intent)
            hideControlPanel()
            stopSelf()
        }

        controlCardView?.findViewById<Button>(R.id.btnOverlayOpenApp)?.setOnClickListener {
            val intent = Intent(this, LiveNoteSessionActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            hideControlPanel()
        }

        windowManager?.addView(controlCardView, cardParams)
        isExpanded = true
    }

    private fun hideControlPanel() {
        if (controlCardView != null) {
            windowManager?.removeView(controlCardView)
            controlCardView = null
        }
        isExpanded = false
    }

    private fun updateOverlayData(subject: String, segment: String, isSessionActive: Boolean) {
        controlCardView?.findViewById<TextView>(R.id.tvOverlaySubject)?.text = subject
        controlCardView?.findViewById<TextView>(R.id.tvOverlaySegment)?.text = segment
        val statusText = if (isSessionActive) "● Taking Notes" else "OFF"
        controlCardView?.findViewById<TextView>(R.id.tvOverlayStatus)?.text = statusText
    }

    override fun onDestroy() {
        super.onDestroy()
        hideControlPanel()
        if (pillView != null) {
            windowManager?.removeView(pillView)
            pillView = null
        }
    }
}
