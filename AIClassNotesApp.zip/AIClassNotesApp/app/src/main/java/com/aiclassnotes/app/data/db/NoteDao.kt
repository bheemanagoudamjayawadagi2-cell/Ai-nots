package com.aiclassnotes.app.data.db

import androidx.room.*
import com.aiclassnotes.app.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
    @Query("SELECT * FROM subjects ORDER BY displayOrder ASC")
    fun getAllSubjects(): Flow<List<SubjectEntity>>

    @Query("SELECT * FROM subjects WHERE id = :subjectId")
    suspend fun getSubjectById(subjectId: Long): SubjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubjects(subjects: List<SubjectEntity>): List<Long>

    @Query("SELECT * FROM segments WHERE subjectId = :subjectId ORDER BY segmentNumber ASC")
    fun getSegmentsForSubject(subjectId: Long): Flow<List<SegmentEntity>>

    @Query("SELECT * FROM segments WHERE id = :segmentId")
    suspend fun getSegmentById(segmentId: Long): SegmentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSegments(segments: List<SegmentEntity>)

    @Update
    suspend fun updateSegment(segment: SegmentEntity)

    @Query("SELECT * FROM note_sessions WHERE segmentId = :segmentId ORDER BY timestamp DESC")
    fun getSessionsForSegment(segmentId: Long): Flow<List<NoteSessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: NoteSessionEntity): Long

    @Update
    suspend fun updateSession(session: NoteSessionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPage(page: NotePageEntity): Long

    @Query("SELECT * FROM note_pages WHERE sessionId = :sessionId ORDER BY pageIndex ASC")
    suspend fun getPagesForSession(sessionId: Long): List<NotePageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertElement(element: NoteElementEntity): Long

    @Query("SELECT * FROM note_elements WHERE pageId = :pageId ORDER BY linePosition ASC")
    suspend fun getElementsForPage(pageId: Long): List<NoteElementEntity>

    @Query("SELECT COUNT(*) FROM subjects")
    suspend fun getSubjectCount(): Int

    @Query("SELECT COUNT(*) FROM note_sessions WHERE segmentId = :segmentId")
    fun getNoteCountForSegment(segmentId: Long): Flow<Int>
}
