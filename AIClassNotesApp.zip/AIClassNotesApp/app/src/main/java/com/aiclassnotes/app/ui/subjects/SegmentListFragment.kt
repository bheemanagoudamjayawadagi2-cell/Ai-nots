package com.aiclassnotes.app.ui.subjects

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.aiclassnotes.app.AIClassNotesApplication
import com.aiclassnotes.app.R
import com.aiclassnotes.app.data.model.SegmentEntity
import com.aiclassnotes.app.databinding.FragmentSegmentListBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class SegmentListFragment : Fragment() {

    private var _binding: FragmentSegmentListBinding? = null
    private val binding get() = _binding!!

    private var subjectId: Long = 1
    private var subjectName: String = "Managerial Economics"
    private var adapter: SegmentAdapter? = null

    companion object {
        fun newInstance(subjectId: Long, subjectName: String): SegmentListFragment {
            return SegmentListFragment().apply {
                arguments = Bundle().apply {
                    putLong("subject_id", subjectId)
                    putString("subject_name", subjectName)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        subjectId = arguments?.getLong("subject_id") ?: 1
        subjectName = arguments?.getString("subject_name") ?: "Managerial Economics"
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSegmentListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tvSubjectHeader.text = subjectName
        binding.rvSegments.layoutManager = LinearLayoutManager(requireContext())

        val app = requireActivity().application as AIClassNotesApplication
        val repo = app.repository

        adapter = SegmentAdapter(emptyList(),
            onSegmentClicked = { segment ->
                showSavedNotesForSegment(segment)
            },
            onEditClicked = { segment ->
                showRenameDialog(segment)
            }
        )
        binding.rvSegments.adapter = adapter

        viewLifecycleOwner.lifecycleScope.launch {
            repo.getSegmentsForSubject(subjectId).collectLatest { segments ->
                adapter?.updateData(segments)
            }
        }
    }

    private fun showRenameDialog(segment: SegmentEntity) {
        val app = requireActivity().application as AIClassNotesApplication
        val repo = app.repository

        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_rename_segment, null)
        val editText = dialogView.findViewById<EditText>(R.id.etSegmentName)
        editText.setText(segment.name)

        val dialog = AlertDialog.Builder(requireContext())
            .setView(dialogView)
            .create()

        dialogView.findViewById<View>(R.id.btnCancelRename).setOnClickListener {
            dialog.dismiss()
        }

        dialogView.findViewById<View>(R.id.btnSaveRename).setOnClickListener {
            val newName = editText.text.toString().trim()
            if (newName.isNotEmpty()) {
                viewLifecycleOwner.lifecycleScope.launch {
                    repo.renameSegment(segment.id, newName)
                    Toast.makeText(requireContext(), "Renamed to: $newName", Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                }
            }
        }

        dialog.show()
    }

    private fun showSavedNotesForSegment(segment: SegmentEntity) {
        val app = requireActivity().application as AIClassNotesApplication
        val repo = app.repository

        viewLifecycleOwner.lifecycleScope.launch {
            repo.getSessionsForSegment(segment.id).collectLatest { sessions ->
                if (sessions.isEmpty()) {
                    AlertDialog.Builder(requireContext())
                        .setTitle(segment.name)
                        .setMessage("No notes yet.\n\nNotes will appear here after you start a note-taking session.")
                        .setPositiveButton("OK", null)
                        .show()
                } else {
                    // Open Saved Note Detail
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
