package com.aiclassnotes.app.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.aiclassnotes.app.AIClassNotesApplication
import com.aiclassnotes.app.R
import com.aiclassnotes.app.data.model.SubjectEntity
import com.aiclassnotes.app.databinding.FragmentHomeBinding
import com.aiclassnotes.app.ui.MainActivity
import com.aiclassnotes.app.ui.subjects.SegmentListFragment
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val app = requireActivity().application as AIClassNotesApplication
        val repo = app.repository

        binding.rvSubjects.layoutManager = LinearLayoutManager(requireContext())

        viewLifecycleOwner.lifecycleScope.launch {
            repo.allSubjects.collectLatest { subjects ->
                binding.rvSubjects.adapter = SubjectAdapter(subjects) { subject ->
                    openSubjectSegments(subject)
                }
            }
        }

        binding.btnStartNotesMain.setOnClickListener {
            (activity as? MainActivity)?.startNoteTakingFlow()
        }
    }

    private fun openSubjectSegments(subject: SubjectEntity) {
        val fragment = SegmentListFragment.newInstance(subject.id, subject.name)
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .addToBackStack(null)
            .commit()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
