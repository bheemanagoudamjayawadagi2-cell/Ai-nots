package com.aiclassnotes.app.ui.subjects

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.aiclassnotes.app.R
import com.aiclassnotes.app.data.model.SegmentEntity

class SegmentAdapter(
    private var segments: List<SegmentEntity>,
    private val onSegmentClicked: (SegmentEntity) -> Unit,
    private val onEditClicked: (SegmentEntity) -> Unit
) : RecyclerView.Adapter<SegmentAdapter.SegmentViewHolder>() {

    class SegmentViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvSegmentName)
        val tvNotesCount: TextView = view.findViewById(R.id.tvNotesCount)
        val btnEdit: ImageButton = view.findViewById(R.id.btnEditSegment)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SegmentViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_segment, parent, false)
        return SegmentViewHolder(view)
    }

    override fun onBindViewHolder(holder: SegmentViewHolder, position: Int) {
        val segment = segments[position]
        holder.tvName.text = segment.name
        holder.tvNotesCount.text = "Tap to view saved notes"
        holder.itemView.setOnClickListener { onSegmentClicked(segment) }
        holder.btnEdit.setOnClickListener { onEditClicked(segment) }
    }

    override fun getItemCount(): Int = segments.size

    fun updateData(newSegments: List<SegmentEntity>) {
        segments = newSegments
        notifyDataSetChanged()
    }
}
