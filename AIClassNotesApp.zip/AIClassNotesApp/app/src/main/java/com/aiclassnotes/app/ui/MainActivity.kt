package com.aiclassnotes.app.ui

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.aiclassnotes.app.AIClassNotesApplication
import com.aiclassnotes.app.R
import com.aiclassnotes.app.data.model.SegmentEntity
import com.aiclassnotes.app.data.model.SubjectEntity
import com.aiclassnotes.app.databinding.ActivityMainBinding
import com.aiclassnotes.app.service.MediaCaptureService
import com.aiclassnotes.app.ui.home.HomeFragment
import com.aiclassnotes.app.ui.session.LiveNoteSessionActivity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var selectedSubject: SubjectEntity? = null
    private var selectedSegment: SegmentEntity? = null

    // MediaProjection screen capture launcher
    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            onScreenCaptureAuthorized(result.resultCode, result.data!!)
        } else {
            Toast.makeText(this, "Screen capture permission was not authorized.", Toast.LENGTH_SHORT).show()
        }
    }

    // Audio and Notification permissions launcher
    private val permissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        if (audioGranted) {
            checkOverlayAndScreenCapture()
        } else {
            Toast.makeText(this, "Audio permission is required to capture lecture voice.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, HomeFragment())
                .commit()
        }
    }

    /**
     * Complete 4-Step Start Note-Taking Flow:
     * 1. SELECT SUBJECT
     * 2. SELECT SEGMENT
     * 3. PERMISSION EXPLANATION & CHECK
     * 4. READY -> Explicit START NOTES click
     */
    fun startNoteTakingFlow() {
        val app = application as AIClassNotesApplication
        val repo = app.repository

        lifecycleScope.launch {
            val subjects = repo.allSubjects.first()
            showSelectSubjectDialog(subjects)
        }
    }

    private fun showSelectSubjectDialog(subjects: List<SubjectEntity>) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_select_subject, null)
        val rg = dialogView.findViewById<RadioGroup>(R.id.rgSubjects)

        subjects.forEachIndexed { index, subject ->
            val rb = RadioButton(this).apply {
                id = View.generateViewId()
                text = "${index + 1}. ${subject.name} — ${subject.semester}"
                textSize = 15f
                setPadding(12, 16, 12, 16)
            }
            rg.addView(rb)
            if (index == 0) rb.isChecked = true
        }

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        dialogView.findViewById<View>(R.id.btnCancelSubject).setOnClickListener {
            dialog.dismiss()
        }

        dialogView.findViewById<View>(R.id.btnNextSubject).setOnClickListener {
            val checkedId = rg.checkedRadioButtonId
            val selectedIndex = rg.indexOfChild(dialogView.findViewById(checkedId))
            if (selectedIndex in subjects.indices) {
                selectedSubject = subjects[selectedIndex]
                dialog.dismiss()
                loadAndShowSegments(selectedSubject!!)
            }
        }

        dialog.show()
    }

    private fun loadAndShowSegments(subject: SubjectEntity) {
        val app = application as AIClassNotesApplication
        lifecycleScope.launch {
            val segments = app.repository.getSegmentsForSubject(subject.id).first()
            showSelectSegmentDialog(subject, segments)
        }
    }

    private fun showSelectSegmentDialog(subject: SubjectEntity, segments: List<SegmentEntity>) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_select_segment, null)
        dialogView.findViewById<TextView>(R.id.tvSelectedSubjectHeader).text = "Subject: ${subject.name}"
        val rg = dialogView.findViewById<RadioGroup>(R.id.rgSegments)

        segments.forEachIndexed { index, segment ->
            val rb = RadioButton(this).apply {
                id = View.generateViewId()
                text = segment.name
                textSize = 15f
                setPadding(12, 16, 12, 16)
            }
            rg.addView(rb)
            if (index == 0) rb.isChecked = true
        }

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        dialogView.findViewById<View>(R.id.btnBackSegment).setOnClickListener {
            dialog.dismiss()
            startNoteTakingFlow()
        }

        dialogView.findViewById<View>(R.id.btnProceedSegment).setOnClickListener {
            val checkedId = rg.checkedRadioButtonId
            val selectedIndex = rg.indexOfChild(dialogView.findViewById(checkedId))
            if (selectedIndex in segments.indices) {
                selectedSegment = segments[selectedIndex]
                dialog.dismiss()
                verifyPermissionsFlow()
            }
        }

        dialog.show()
    }

    private fun verifyPermissionsFlow() {
        val hasAudio = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val hasOverlay = Settings.canDrawOverlays(this)

        if (!hasAudio || !hasOverlay) {
            showPermissionExplanationDialog()
        } else {
            showReadyScreen()
        }
    }

    private fun showPermissionExplanationDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_permission_explanation, null)

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        dialogView.findViewById<View>(R.id.btnCancelPerm).setOnClickListener {
            dialog.dismiss()
        }

        dialogView.findViewById<View>(R.id.btnGrantPerm).setOnClickListener {
            dialog.dismiss()
            requestRequiredPermissions()
        }

        dialog.show()
    }

    private fun requestRequiredPermissions() {
        val permissionsToRequest = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            permissionsLauncher.launch(permissionsToRequest.toTypedArray())
        } else {
            checkOverlayAndScreenCapture()
        }
    }

    private fun checkOverlayAndScreenCapture() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(this, "Please enable 'Display over other apps' for AI Notes", Toast.LENGTH_LONG).show()
        } else {
            showReadyScreen()
        }
    }

    private fun showReadyScreen() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_ready, null)
        dialogView.findViewById<TextView>(R.id.tvReadySubject).text = "Subject: ${selectedSubject?.name}"
        dialogView.findViewById<TextView>(R.id.tvReadySegment).text = "Segment: ${selectedSegment?.name}"

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        dialogView.findViewById<View>(R.id.btnFinalStartNotes).setOnClickListener {
            dialog.dismiss()
            // Launch MediaProjection screen capture authorization dialog
            val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            screenCaptureLauncher.launch(mpManager.createScreenCaptureIntent())
        }

        dialog.show()
    }

    private fun onScreenCaptureAuthorized(resultCode: Int, data: Intent) {
        val app = application as AIClassNotesApplication
        val repo = app.repository

        lifecycleScope.launch {
            val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())
            val dateStr = dateFormat.format(Date())

            val sessionId = repo.createNoteSession(
                selectedSubject!!.id,
                selectedSegment!!.id,
                dateStr
            )

            // Start Foreground Service
            val serviceIntent = Intent(this@MainActivity, MediaCaptureService::class.java).apply {
                action = MediaCaptureService.ACTION_START
                putExtra(MediaCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(MediaCaptureService.EXTRA_RESULT_DATA, data)
                putExtra(MediaCaptureService.EXTRA_SUBJECT, selectedSubject!!.name)
                putExtra(MediaCaptureService.EXTRA_SEGMENT, selectedSegment!!.name)
                putExtra(MediaCaptureService.EXTRA_SESSION_ID, sessionId)
            }
            startService(serviceIntent)

            // Launch Live Note Session Activity
            val activityIntent = Intent(this@MainActivity, LiveNoteSessionActivity::class.java).apply {
                putExtra("subject_name", selectedSubject!!.name)
                putExtra("segment_name", selectedSegment!!.name)
                putExtra("subject_id", selectedSubject!!.id)
                putExtra("segment_id", selectedSegment!!.id)
                putExtra("session_id", sessionId)
            }
            startActivity(activityIntent)
        }
    }
}
