package com.aiclassnotes.app.data.model

import androidx.room.*

@Entity(tableName = "subjects")
data class SubjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val semester: String,
    val displayOrder: Int
)

@Entity(
    tableName = "segments",
    foreignKeys = [
        ForeignKey(
            entity = SubjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("subjectId")]
)
data class SegmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val segmentNumber: Int,
    val name: String
)

@Entity(
    tableName = "note_sessions",
    foreignKeys = [
        ForeignKey(
            entity = SubjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = SegmentEntity::class,
            parentColumns = ["id"],
            childColumns = ["segmentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("subjectId"), Index("segmentId")]
)
data class NoteSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val segmentId: Long,
    val timestamp: Long,
    val formattedDate: String,
    val title: String,
    val status: String // ACTIVE, PAUSED, COMPLETED
)

@Entity(
    tableName = "note_pages",
    foreignKeys = [
        ForeignKey(
            entity = NoteSessionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("sessionId")]
)
data class NotePageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val pageIndex: Int
)

enum class NoteElementType {
    HEADING,
    DEFINITION,
    BULLET_POINT,
    FORMULA,
    CALCULATION_STEP,
    DIAGRAM
}

@Entity(
    tableName = "note_elements",
    foreignKeys = [
        ForeignKey(
            entity = NotePageEntity::class,
            parentColumns = ["id"],
            childColumns = ["pageId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("pageId")]
)
data class NoteElementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pageId: Long,
    val type: NoteElementType,
    val title: String = "",
    val textContent: String = "",
    val formulaLatex: String? = null,
    val calculationSteps: String? = null, // JSON array of steps
    val diagramJson: String? = null, // JSON vector drawing instructions
    val linePosition: Int, // which ruled line index
    val timestamp: Long = System.currentTimeMillis()
)

data class SubjectWithSegments(
    @Embedded val subject: SubjectEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "subjectId"
    )
    val segments: List<SegmentEntity>
)

data class SegmentWithNotes(
    @Embedded val segment: SegmentEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "segmentId"
    )
    val noteSessions: List<NoteSessionEntity>
)
