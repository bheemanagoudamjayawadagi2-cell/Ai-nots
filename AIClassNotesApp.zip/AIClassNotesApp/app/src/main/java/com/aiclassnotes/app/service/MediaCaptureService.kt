package com.aiclassnotes.app.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.aiclassnotes.app.R
import com.aiclassnotes.app.ai.ClassUnderstandingEngine
import com.aiclassnotes.app.ui.session.LiveNoteSessionActivity
import kotlinx.coroutines.*

enum class SessionState {
    OFF,
    STARTING,
    ACTIVE,
    PAUSED,
    STOPPED
}

class MediaCaptureService : Service() {

    private val binder = LocalBinder()
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var audioRecord: AudioRecord? = null

    private var isRecordingAudio = false
    var currentState: SessionState = SessionState.OFF
        private set

    var currentSubject: String = ""
    var currentSegment: String = ""
    var currentSessionId: Long = -1

    var onStateChangedListener: ((SessionState) -> Unit)? = null
    var onErrorListener: ((String) -> Unit)? = null

    inner class LocalBinder : Binder() {
        fun getService(): MediaCaptureService = this@MediaCaptureService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        when (action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val data = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                val subject = intent.getStringExtra(EXTRA_SUBJECT) ?: ""
                val segment = intent.getStringExtra(EXTRA_SEGMENT) ?: ""
                val sessionId = intent.getLongExtra(EXTRA_SESSION_ID, -1L)

                startForegroundSession(resultCode, data, subject, segment, sessionId)
            }
            ACTION_PAUSE -> pauseSession()
            ACTION_RESUME -> resumeSession()
            ACTION_STOP -> stopAndSaveSession()
        }
        return START_NOT_STICKY
    }

    private fun startForegroundSession(
        resultCode: Int,
        data: Intent?,
        subject: String,
        segment: String,
        sessionId: Long
    ) {
        currentSubject = subject
        currentSegment = segment
        currentSessionId = sessionId

        val notification = createNotification("● Taking Notes: $subject ($segment)")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            }
            startForeground(NOTIFICATION_ID, notification, type)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        // Initialize Real Screen Capture via MediaProjection
        if (resultCode == Activity.RESULT_OK && data != null) {
            val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = mpManager.getMediaProjection(resultCode, data)
            setupVirtualDisplay()
        }

        // Initialize Real Audio Capture via AudioRecord
        setupAudioCapture()

        currentState = SessionState.ACTIVE
        onStateChangedListener?.invoke(currentState)

        // Inform AI engine that session is active
        ClassUnderstandingEngine.instance.onSessionStarted(sessionId, subject, segment)
    }

    private fun setupVirtualDisplay() {
        try {
            val metrics = resources.displayMetrics
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi

            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "AIClassNotesScreenCapture",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                null
            )

            imageReader?.setOnImageAvailableListener({ reader ->
                if (currentState == SessionState.ACTIVE) {
                    val image = reader.acquireLatestImage()
                    if (image != null) {
                        ClassUnderstandingEngine.instance.processScreenFrame(image)
                        image.close()
                    }
                }
            }, null)
        } catch (e: Exception) {
            Log.e("MediaCaptureService", "VirtualDisplay setup failed: ${e.message}")
            onErrorListener?.invoke("Screen capture initialization failed: ${e.message}")
        }
    }

    private fun setupAudioCapture() {
        try {
            val sampleRate = 16000
            val channelConfig = AudioFormat.CHANNEL_IN_MONO
            val audioFormat = AudioFormat.ENCODING_PCM_16BIT
            val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)

            if (bufferSize != AudioRecord.ERROR && bufferSize != AudioRecord.ERROR_BAD_VALUE) {
                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    channelConfig,
                    audioFormat,
                    bufferSize * 2
                )

                if (audioRecord?.state == AudioRecord.STATE_INITIALIZED) {
                    audioRecord?.startRecording()
                    isRecordingAudio = true
                    startAudioProcessingLoop(bufferSize)
                } else {
                    Log.w("MediaCaptureService", "AudioRecord state not initialized")
                    onErrorListener?.invoke("CAPTURE STOPPED: Microphone or internal audio is restricted.")
                }
            }
        } catch (e: SecurityException) {
            Log.e("MediaCaptureService", "Microphone permission not granted: ${e.message}")
            onErrorListener?.invoke("CAPTURE STOPPED: Audio permission not granted.")
        } catch (e: Exception) {
            Log.e("MediaCaptureService", "AudioRecord error: ${e.message}")
            onErrorListener?.invoke("CAPTURE STOPPED: Audio hardware unavailable.")
        }
    }

    private fun startAudioProcessingLoop(bufferSize: Int) {
        scope.launch(Dispatchers.IO) {
            val audioBuffer = ShortArray(bufferSize)
            while (isRecordingAudio && isActive) {
                if (currentState == SessionState.ACTIVE) {
                    val readBytes = audioRecord?.read(audioBuffer, 0, bufferSize) ?: -1
                    if (readBytes > 0) {
                        ClassUnderstandingEngine.instance.processAudioBuffer(audioBuffer, readBytes)
                    }
                } else if (currentState == SessionState.PAUSED) {
                    delay(200) // Sleep while paused
                }
            }
        }
    }

    fun pauseSession() {
        if (currentState == SessionState.ACTIVE) {
            currentState = SessionState.PAUSED
            updateNotification("⏸ Note-Taking Paused: $currentSubject")
            onStateChangedListener?.invoke(currentState)
            ClassUnderstandingEngine.instance.onSessionPaused()
        }
    }

    fun resumeSession() {
        if (currentState == SessionState.PAUSED) {
            currentState = SessionState.ACTIVE
            updateNotification("● Taking Notes: $currentSubject ($currentSegment)")
            onStateChangedListener?.invoke(currentState)
            ClassUnderstandingEngine.instance.onSessionResumed()
        }
    }

    fun stopAndSaveSession() {
        currentState = SessionState.STOPPED
        isRecordingAudio = false

        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (e: Exception) {
            Log.e("MediaCaptureService", "Error stopping audio: ${e.message}")
        }
        audioRecord = null

        try {
            virtualDisplay?.release()
            imageReader?.close()
            mediaProjection?.stop()
        } catch (e: Exception) {
            Log.e("MediaCaptureService", "Error stopping projection: ${e.message}")
        }
        virtualDisplay = null
        imageReader = null
        mediaProjection = null

        ClassUnderstandingEngine.instance.onSessionStopped()
        onStateChangedListener?.invoke(currentState)

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotification(contentText: String): Notification {
        val channelId = "ai_class_notes_session_channel"
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "AI Class Notes Session",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows active class note-taking status and controls"
            }
            manager.createNotificationChannel(channel)
        }

        val openAppIntent = Intent(this, LiveNoteSessionActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("AI Class Notes")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, createNotification(text))
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        if (currentState != SessionState.STOPPED) {
            stopAndSaveSession()
        }
    }

    companion object {
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "com.aiclassnotes.app.ACTION_START"
        const val ACTION_PAUSE = "com.aiclassnotes.app.ACTION_PAUSE"
        const val ACTION_RESUME = "com.aiclassnotes.app.ACTION_RESUME"
        const val ACTION_STOP = "com.aiclassnotes.app.ACTION_STOP"

        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_SUBJECT = "extra_subject"
        const val EXTRA_SEGMENT = "extra_segment"
        const val EXTRA_SESSION_ID = "extra_session_id"
    }
}
