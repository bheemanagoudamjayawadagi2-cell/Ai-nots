# Proguard rules for AI Class Notes
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.room.* *;
}
