# AI Class Notes — Android Application

A native Android application designed strictly around zero-unprompted-activation, explicit user-initiated note sessions, real system permissions, foreground capture service, draggable floating assistant overlay, and progressive handwritten study notes on authentic A4 ruled notebook paper.

---

## 1. Zero Automatic Activation Architecture (Strict Rule)

- **App Open**: NO note taking is active. NO audio listening, NO screen capture, NO note generation.
- **App Minimized**: NO note taking is active unless explicitly started.
- **Floating Pill**: Tapping the floating pill when no session is active will NEVER start notes automatically; it only routes the user to the selection flow.
- **Strict 4-Step Start Sequence**:
  1. User explicitly taps `START NOTES`.
  2. Dialog: `SELECT SUBJECT` (5 Semester-1 MBA courses).
  3. Dialog: `SELECT SEGMENT` (Segment 1 through 6, with custom editable names).
  4. Permission Verification / Explanation Screen.
  5. Screen: `READY` → User explicitly taps `[ START NOTES ]` to begin the session.

---

## 2. Project Architecture & Components

- **Application (`AIClassNotesApplication.kt`)**: Initializes Room SQLite database with the 5 subjects and 6 segments each. Contains **ZERO fake notes** or pre-written mockups.
- **Data Layer (`com.aiclassnotes.app.data`)**:
  - `AppDatabase.kt`, `NoteDao.kt`, `Models.kt`, `NoteRepository.kt`: Persistent Room database tracking subjects, segments, sessions, pages, and structured note elements (Headings, Definitions, Formulas, Calculations, Diagrams).
- **Foreground Capture Service (`MediaCaptureService.kt`)**:
  - Utilizes Android's official `MediaProjection` API for user-authorized screen frames.
  - Utilizes Android's official `AudioRecord` for lecture speech capture.
  - State machine supporting `ACTIVE`, `PAUSED`, `RESUMED`, and `STOPPED`.
  - Ongoing system notification with action buttons: `PAUSE`, `RESUME`, `STOP & SAVE`.
- **Floating Overlay Assistant (`FloatingOverlayService.kt`)**:
  - Draggable `AI NOTES` floating pill using `SYSTEM_ALERT_WINDOW`.
  - Expanding control panel displaying active Subject, Segment, Status (`● Taking Notes` or `⏸ Paused`), and `PAUSE`, `RESUME`, `STOP & SAVE` controls.
- **Live A4 Ruled Paper View (`A4RuledPaperView.kt`)**:
  - Renders true A4 portrait proportion (210 x 297 mm, 1 : 1.414 aspect ratio).
  - Clean white sheet, slate horizontal ruled lines, pink left margin rule.
  - Classic royal blue ballpoint pen ink (`#0F3876`) with realistic pressure and curves.
  - Vector diagrams (e.g. Price vs Quantity Demand/Supply curves, flowcharts) drawn live without placeholders.
  - Progressive drawing animations as lecture insights occur.
  - Automatic pagination to Page 2, 3, etc. when filled.

---

## 3. How to Build the APK (1-Minute Step-by-Step)

### Option A: Via Android Studio (Recommended)
1. Extract `AI_Class_Notes_Android_App.zip`.
2. Open Android Studio (Ladybug / Hedgehog or newer).
3. Select **File → Open...** and choose the extracted `AIClassNotesApp` folder.
4. Allow Gradle to sync dependencies.
5. In the top menu, click **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Android Studio will compile the debug APK to:
   `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer `app-debug.apk` to your phone or click **Run 'app'** to install directly via USB/Wi-Fi debugging.

### Option B: Via Command Line (Terminal)
1. Open Terminal or Command Prompt in the project folder:
   ```bash
   cd AIClassNotesApp
   ```
2. Build the debug APK using the included Gradle wrapper:
   - On Linux / macOS:
     ```bash
     ./gradlew assembleDebug
     ```
   - On Windows:
     ```cmd
     gradlew.bat assembleDebug
     ```
3. The APK will be ready at:
   `app/build/outputs/apk/debug/app-debug.apk`

---

## 4. Installing on Your Android Phone

1. Copy `app-debug.apk` to your phone (via Google Drive, USB cable, or WhatsApp/Telegram).
2. Open the file on your Android phone and tap **Install**.
3. If prompted by Android, toggle **Allow installation from this source**.
4. Open **AI Class Notes**!
